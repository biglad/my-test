from slyguy.constants import REPO_DOMAIN

## NEWS ##
NEWS_URL = REPO_DOMAIN+'/.repo/news.json.gz'
ADDONS_URL = REPO_DOMAIN+'/.repo/addons.json.gz'
ADDONS_MD5 = REPO_DOMAIN+'/.repo/addons.xml.md5'
NEWS_CHECK_TIME = 1800 #30mins
UPDATES_CHECK_TIME = 1800 #30mins
